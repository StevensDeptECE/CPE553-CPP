/*
    In C++ and all C-family languages (C, Java, C#, JavaScript, Objective-C)
    SPACE DON'T MATTER except breaking up tokens

    token is keyword (int)
    variable name (abc123)
    constant (123.456e+2 or 123 or -12412512LL)
    operators:  += is not the same as + = and by the way, you cannot write =< the operator is <=

    Every comment turns into a SINGLE SPACE
    #if 0..#endif turns into a single space
*/
int a = 2;
int *p = &a;
int* q = &a;


int

 f
 (
     int x) {
         int abc = 123;
         abc += 2;
         abc +/*comment goes here*/= 3;  // this is NOT +=  abc + = 3;
  return
  
  
  
   x 
   * 
     x;
}
