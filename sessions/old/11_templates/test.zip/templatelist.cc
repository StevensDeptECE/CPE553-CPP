#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {
	vector<int> a;
	a.push_back(3);
	a.push_back(1);
	a.push_back(4);

	vector<string> b;
	b.push_back("abc");
	b.push_back("3");

	
}
