int& f() {
	int x = 5;
	return x;
}

int main() {
	int a = f();
